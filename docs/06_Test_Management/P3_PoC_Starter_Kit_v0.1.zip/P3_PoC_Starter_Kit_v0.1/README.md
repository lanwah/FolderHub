# FolderHub P3 PoC Starter Kit

- Workflow: software-predev-workflow-skill V2.6.1
- Stage: P3_HIGH_LEVEL_DESIGN / IN_PROGRESS
- Requirements baseline: REQ-BL-1.0 (read-only input)
- Related decisions: ADR-034 through ADR-038
- Status: DRAFT / ISOLATED TEST HARNESS ONLY — NOT A PRODUCT IMPLEMENTATION

## Purpose

This starter kit prepares a safe, isolated harness for the next P3 validation step while the actual Windows test environments remain un-inventoried (Q-P3-TEST-002). It provides:

1. A read-only Windows environment inventory script copied from the current project record.
2. A process-lifecycle simulator for the high-level ADR-038 policy: bounded restarts and backoff while the simulated Main Process remains alive.
3. Narrow stop/cleanup scripts for PoC child processes and generated test artifacts.
4. A test matrix and evidence template.

## Critical boundaries

- PowerShell is used only as a test driver/simulator. It does **not** select the FolderHub product runtime, framework, IPC library, database, or UI technology.
- The worker is a dummy child process. Process liveness is not application health.
- This kit does not implement or validate Named Pipes, caller identity, security descriptors, serialization, persistence, CardDefinition/CardPresentationState reconciliation, desktop windows, Explorer integration, or Keep Cards=ON behavior.
- No production FolderHub data is read or written. No service, scheduled task, registry key, startup entry, or permanent background process is installed.
- Test values are explicit command-line inputs. The kit does not claim that any retry count, timeout, or backoff value is approved product behavior.
- The environment script records identifying machine/user metadata. Review and redact output before sharing.

## Requirements

- Windows with Windows PowerShell 5.1 (`powershell.exe`).
- Permission to start/stop child PowerShell processes in the current user session.
- No elevation should be needed for the basic process simulator. Run with the least privilege available.

The environment inventory script uses CIM and WinForms screen geometry. Screen geometry is not a DPI measurement; DPI awareness and per-monitor DPI behavior require separate target-OS tests.

## 0. Deploy the kit to a test workspace (optional)

```powershell
.\scripts\Deploy-FolderHubPoCKit.ps1 -DestinationPath "$env:TEMP\FolderHub-P3-PoC"
```

Deployment copies only this kit to a new directory and refuses to overwrite an existing destination. It does not install a Windows service or register any startup behavior.

## 1. Inventory the environment

From this kit directory:

```powershell
.\scripts\Get-FolderHubEnvironment_v0.2.ps1 -OutputPath .\artifacts\environment-inventory.json -RedactIdentity
```

Review the JSON before sharing. Record the environment as `INVENTORIED` only after manually checking OS edition/build/patch level, VM/physical status, Local/RDP session, privileges, display topology, and test access method.

## 2. Run the recovery simulator

All numeric parameters are explicit because product values have not been selected. Example values below are **experiment inputs only**, not approved FolderHub settings:

```powershell
.\scripts\Invoke-FolderHubRecoveryPoC.ps1 `
  -MaxRestartAttempts 2 `
  -InitialBackoffSeconds 1 `
  -MaxBackoffSeconds 4 `
  -BackoffMultiplier 2 `
  -CrashAfterSeconds 1 `
  -StableObservationSeconds 5 `
  -CrashAttempts 1 `
  -OutputDirectory .\artifacts
```

This simulates launch 1 failing, followed by a stable dummy worker on the next launch. The `STABLE_WINDOW_OBSERVED_NOT_HEALTH_PROOF` result means only that the dummy process remained alive during the observation window.

Repeated failure example (again, experiment inputs only):

```powershell
.\scripts\Invoke-FolderHubRecoveryPoC.ps1 `
  -MaxRestartAttempts 2 `
  -InitialBackoffSeconds 1 `
  -MaxBackoffSeconds 2 `
  -BackoffMultiplier 2 `
  -CrashAfterSeconds 1 `
  -StableObservationSeconds 3 `
  -CrashAttempts 1,2,3 `
  -OutputDirectory .\artifacts
```

The expected result is `DEGRADED_RETRY_BUDGET_EXHAUSTED`; total launches are the initial launch plus the configured number of allowed restarts.

Normal-exit example:

```powershell
.\scripts\Invoke-FolderHubRecoveryPoC.ps1 `
  -MaxRestartAttempts 2 `
  -InitialBackoffSeconds 1 `
  -MaxBackoffSeconds 2 `
  -BackoffMultiplier 2 `
  -CrashAfterSeconds 1 `
  -StableObservationSeconds 3 `
  -CrashAttempts @() `
  -NormalExitAttempt 1 `
  -NormalExitAfterSeconds 1 `
  -OutputDirectory .\artifacts
```

To simulate Main Process exit during backoff, set `-MainProcessLifetimeSeconds` shorter than the selected backoff delay. This is only a control-flow simulation; it is not a proof of the production Keep Cards lifecycle.

## 3. Stop and clean up

If a worker remains after an interrupted run:

```powershell
.\scripts\Stop-FolderHubRecoveryPoC.ps1 -OutputDirectory .\artifacts
```

Remove generated logs only when they are no longer needed:

```powershell
.\scripts\Remove-FolderHubPoCArtifacts.ps1 -OutputDirectory .\artifacts -WhatIf
.\scripts\Remove-FolderHubPoCArtifacts.ps1 -OutputDirectory .\artifacts -Confirm
```

The cleanup script refuses paths outside this kit's `artifacts` directory. Preserve evidence before cleanup.

## Evidence

For each run, retain:

- environment inventory JSON (redacted copy if shared);
- exact command line and parameter values;
- `recovery-summary-*.json` and `recovery-events-*.jsonl`;
- observed process count before/during/after;
- test case ID, result, operator, timestamp, OS build, PowerShell version;
- anomalies, screenshots/log references, defect IDs, Git Commit/Tag when available.

See `docs/PoC_Test_Matrix.md` and `docs/PoC_Evidence_Record_Template.md`.
