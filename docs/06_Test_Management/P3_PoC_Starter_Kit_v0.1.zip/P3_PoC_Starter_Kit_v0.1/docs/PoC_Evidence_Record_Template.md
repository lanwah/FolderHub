# FolderHub P3 PoC Evidence Record

- Evidence ID:
- Test ID:
- Date/time (local + UTC):
- Operator:
- Environment ID:
- OS Product / Version / Edition / Build / UBR:
- Architecture:
- Physical / VM:
- Local / RDP:
- User SID / Logon SID (store securely; redact before sharing):
- Session ID:
- PowerShell version:
- Display topology / scaling / DPI test notes:
- FolderHub / PoC build:
- Git branch / Commit / Annotated Tag:
- Exact command and parameters:
- Preconditions:
- Steps executed:
- Expected result:
- Actual result:
- Result: PASS / FAIL / BLOCKED / NOT RUN
- Process count before / during / after:
- Event log / summary paths:
- Screenshots / other evidence:
- Deviations / anomalies:
- Related defect / issue / risk:
- Reviewer:
- Notes and limitations:

> A result applies only to the recorded test, build, and environment. Do not generalize a single environment result to the full Windows support matrix.
