# FolderHub P3 Isolated PoC Test Matrix

- ID: FH-P3-POC-MTX-001
- Version: v0.1
- Status: DRAFT / NOT EXECUTED
- Inputs: REQ-BL-1.0; ADR-034–ADR-038; P3-06 v0.4; P3-07 v0.1

| Test ID | Scope | Scenario | Expected evidence | Status |
|---|---|---|---|---|
| REC-POC-01 | Harness only | One simulated crash, next worker remains alive | bounded restart, backoff event, stable-window marker | NOT RUN |
| REC-POC-02 | Harness only | All launches crash | restart count never exceeds configured cap; DEGRADED | NOT RUN |
| REC-POC-03 | Harness only | Worker exits normally | no automatic restart | NOT RUN |
| REC-POC-04 | Harness only | Main Process lifetime expires during backoff | no subsequent worker launch | NOT RUN |
| REC-POC-05 | Harness only | Harness is interrupted while worker is alive | cleanup script stops only recorded PoC worker | NOT RUN |
| ENV-POC-01 | Environment inventory | Collect OS/build/session/display metadata | JSON output and manual review | NOT RUN |
| NP-01..NP-11 | Windows security PoC | Named Pipes access control, identity, session isolation, remote rejection, malformed input and lifecycle | target-Windows logs and security evidence | BLOCKED: environment/runtime harness not yet validated |
| CP-01..CP-10 | Persistence PoC | CardPresentationState durability, crash windows, recovery and reconciliation | data snapshots, fault injection and consistency checks | BLOCKED: product persistence technology not selected |
| DESK-01.. | Desktop integration | Explorer restart, z-order, DPI, multi-monitor, RDP, logoff, upgrade/rollback | screenshots, event logs and per-OS results | BLOCKED: environment inventory pending |

## Interpretation

The supplied scripts are only a preparation harness. Even a successful REC-POC-01..05 run cannot be used to mark NP, CP, desktop integration, actual CardHost recovery, compatibility, or RISK-002 mitigation as PASS. Actual product PoCs require the selected runtime/implementation and an inventoried Windows environment. Any proposed numeric parameter remains an experiment input until evidence is reviewed and the design decision is explicitly recorded.
