# FolderHub P3 PoC Runbook

## Safety preflight

1. Use a disposable VM or dedicated test account where possible.
2. Do not point the PoC at production FolderHub data.
3. Do not run as Administrator unless a specific test requires it and that requirement is documented.
4. Capture a baseline process list and environment inventory.
5. Confirm no unrelated process is named in `active-worker.json` before stopping anything.
6. Preserve logs before deleting artifacts.

## Execution order

1. Environment inventory (`ENV-POC-01`).
2. Harness behavior (`REC-POC-01` through `REC-POC-05`).
3. Review logs and confirm launch/restart accounting.
4. Only after runtime and target environment are confirmed, implement separate Named Pipes and persistence PoCs.
5. Run the full matrix by OS edition/build and session type.

## Exit criteria for this starter-kit activity

- Scripts are present and statically reviewed.
- Test parameters are explicit and captured.
- Cleanup is bounded to the PoC-owned child process and artifact directory.
- Limitations are visible in README and evidence output.
- No claim is made that actual CardHost, Named Pipes, persistence, or compatibility has passed.
