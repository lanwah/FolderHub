[CmdletBinding()]
param(
    [string]$OutputDirectory = '.\artifacts'
)

$ErrorActionPreference = 'Stop'
$activePath = Join-Path ([System.IO.Path]::GetFullPath($OutputDirectory)) 'active-worker.json'
if (-not (Test-Path -LiteralPath $activePath -PathType Leaf)) {
    Write-Host 'No active PoC worker record found.'
    exit 0
}

$record = Get-Content -LiteralPath $activePath -Raw | ConvertFrom-Json
$workerScript = [string]$record.WorkerScript
$pidValue = [int]$record.Pid
if ([string]::IsNullOrWhiteSpace($workerScript) -or $pidValue -le 0) {
    throw 'Active worker record is invalid; refusing to stop any process.'
}

$process = Get-WmiObject -Class Win32_Process -Filter "ProcessId = $pidValue" -ErrorAction SilentlyContinue
if ($null -eq $process) {
    Remove-Item -LiteralPath $activePath -Force
    Write-Host 'Recorded worker is already stopped; stale record removed.'
    exit 0
}

if ([string]::IsNullOrEmpty($process.CommandLine) -or $process.CommandLine.IndexOf($workerScript, [StringComparison]::OrdinalIgnoreCase) -lt 0) {
    throw "PID $pidValue does not match the recorded PoC worker command line; refusing to stop it."
}
Stop-Process -Id $pidValue -Force
Remove-Item -LiteralPath $activePath -Force
Write-Host "Stopped PoC worker PID $pidValue. No other process was targeted."
