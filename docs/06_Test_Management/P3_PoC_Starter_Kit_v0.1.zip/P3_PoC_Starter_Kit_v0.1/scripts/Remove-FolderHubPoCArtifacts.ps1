[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [string]$OutputDirectory = '.\artifacts'
)

$ErrorActionPreference = 'Stop'
$root = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$target = [System.IO.Path]::GetFullPath($OutputDirectory)
$artifactsRoot = [System.IO.Path]::GetFullPath((Join-Path $root 'artifacts'))
$artifactsPrefix = $artifactsRoot.TrimEnd([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar) + [System.IO.Path]::DirectorySeparatorChar
if ($target -ne $artifactsRoot -and -not $target.StartsWith($artifactsPrefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing to remove path outside the PoC artifacts directory: $target"
}
if (-not (Test-Path -LiteralPath $target -PathType Container)) {
    Write-Host 'Artifact directory does not exist.'
    exit 0
}

if ($PSCmdlet.ShouldProcess($target, 'Remove PoC logs and summaries')) {
    Remove-Item -LiteralPath $target -Recurse -Force
    Write-Host "Removed PoC artifacts: $target"
}
