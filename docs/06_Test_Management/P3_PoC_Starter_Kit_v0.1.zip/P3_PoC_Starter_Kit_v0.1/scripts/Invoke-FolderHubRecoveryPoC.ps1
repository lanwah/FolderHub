[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateRange(0, 100)]
    [int]$MaxRestartAttempts,

    [Parameter(Mandatory = $true)]
    [ValidateRange(1, 3600)]
    [int]$InitialBackoffSeconds,

    [Parameter(Mandatory = $true)]
    [ValidateRange(1, 3600)]
    [int]$MaxBackoffSeconds,

    [Parameter(Mandatory = $true)]
    [ValidateRange(1, 10)]
    [int]$BackoffMultiplier,

    [Parameter(Mandatory = $true)]
    [ValidateRange(1, 3600)]
    [int]$CrashAfterSeconds,

    [Parameter(Mandatory = $true)]
    [ValidateRange(1, 3600)]
    [int]$StableObservationSeconds,

    [int[]]$CrashAttempts = @(1),
    [int]$NormalExitAttempt = 0,
    [ValidateRange(1, 3600)]
    [int]$NormalExitAfterSeconds = 1,
    [ValidateRange(0, 86400)]
    [int]$MainProcessLifetimeSeconds = 0,
    [string]$OutputDirectory = '.\artifacts'
)

$ErrorActionPreference = 'Stop'

if ($MaxBackoffSeconds -lt $InitialBackoffSeconds) {
    throw 'MaxBackoffSeconds must be greater than or equal to InitialBackoffSeconds.'
}
if ($NormalExitAttempt -gt 0 -and ($CrashAttempts -contains $NormalExitAttempt)) {
    throw 'NormalExitAttempt cannot also be listed in CrashAttempts.'
}

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$workerScript = Join-Path $scriptRoot 'Start-FolderHubRecoveryWorker.ps1'
if (-not (Test-Path -LiteralPath $workerScript -PathType Leaf)) {
    throw "Worker script not found: $workerScript"
}

$resolvedOutput = [System.IO.Path]::GetFullPath($OutputDirectory)
if (-not (Test-Path -LiteralPath $resolvedOutput -PathType Container)) {
    New-Item -ItemType Directory -Path $resolvedOutput -Force | Out-Null
}
$runId = [Guid]::NewGuid().ToString('N')
$eventLog = Join-Path $resolvedOutput ("recovery-events-{0}.jsonl" -f $runId)
$summaryPath = Join-Path $resolvedOutput ("recovery-summary-{0}.json" -f $runId)
$activePath = Join-Path $resolvedOutput 'active-worker.json'
$powerShellExe = Join-Path $PSHOME 'powershell.exe'
if (-not (Test-Path -LiteralPath $powerShellExe -PathType Leaf)) {
    throw "This harness requires Windows PowerShell (powershell.exe). Current PSHOME: $PSHOME"
}

$startedAt = [DateTime]::UtcNow
$mainDeadline = $null
if ($MainProcessLifetimeSeconds -gt 0) {
    $mainDeadline = $startedAt.AddSeconds($MainProcessLifetimeSeconds)
}

$script:workerProcess = $null
$script:result = 'UNSET'
$script:launchCount = 0
$script:restartCount = 0
$script:failureCount = 0

function Write-Event {
    param([string]$Name, [hashtable]$Data = @{})
    $record = [ordered]@{
        TimestampUtc = [DateTime]::UtcNow.ToString('o')
        RunId = $runId
        Event = $Name
        Data = $Data
    }
    ($record | ConvertTo-Json -Depth 8 -Compress) | Add-Content -LiteralPath $eventLog -Encoding UTF8
}

function Test-MainAlive {
    if ($null -eq $mainDeadline) { return $true }
    return ([DateTime]::UtcNow -lt $mainDeadline)
}

function Get-BackoffSeconds {
    param([int]$RestartNumber)
    $value = [double]$InitialBackoffSeconds
    for ($i = 1; $i -lt $RestartNumber; $i++) {
        $value = [Math]::Min([double]$MaxBackoffSeconds, ($value * $BackoffMultiplier))
    }
    return [int][Math]::Ceiling($value)
}

function Stop-OwnedWorker {
    if ($null -ne $script:workerProcess) {
        try {
            $script:workerProcess.Refresh()
            if (-not $script:workerProcess.HasExited) {
                Stop-Process -Id $script:workerProcess.Id -Force -ErrorAction Stop
                Write-Event -Name 'WORKER_CLEANED_UP' -Data @{ Pid = $script:workerProcess.Id }
            }
        } catch {
            Write-Event -Name 'WORKER_CLEANUP_ERROR' -Data @{ Message = $_.Exception.Message }
        }
        $script:workerProcess = $null
    }
    if (Test-Path -LiteralPath $activePath) {
        Remove-Item -LiteralPath $activePath -Force -ErrorAction SilentlyContinue
    }
}

try {
    Write-Event -Name 'RUN_STARTED' -Data @{
        MaxRestartAttempts = $MaxRestartAttempts
        InitialBackoffSeconds = $InitialBackoffSeconds
        MaxBackoffSeconds = $MaxBackoffSeconds
        BackoffMultiplier = $BackoffMultiplier
        CrashAttempts = @($CrashAttempts)
        CrashAfterSeconds = $CrashAfterSeconds
        StableObservationSeconds = $StableObservationSeconds
        NormalExitAttempt = $NormalExitAttempt
        MainProcessLifetimeSeconds = $MainProcessLifetimeSeconds
        HarnessOnly = $true
    }

    while ($true) {
        if (-not (Test-MainAlive)) {
            $script:result = 'MAIN_PROCESS_EXITED_NO_FURTHER_RESTART'
            Write-Event -Name 'MAIN_PROCESS_EXITED' -Data @{ LaunchCount = $script:launchCount; RestartCount = $script:restartCount }
            break
        }

        $script:launchCount++
        $isCrashAttempt = ($CrashAttempts -contains $script:launchCount)
        $isNormalExit = ($NormalExitAttempt -eq $script:launchCount)
        $exitAfter = 0
        $exitCode = 0
        if ($isCrashAttempt) {
            $exitAfter = $CrashAfterSeconds
            $exitCode = 73
        } elseif ($isNormalExit) {
            $exitAfter = $NormalExitAfterSeconds
            $exitCode = 0
        }

        $processArgs = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "{0}" -Attempt {1} -ExitAfterSeconds {2} -ExitCode {3}' -f $workerScript, $script:launchCount, $exitAfter, $exitCode
        $script:workerProcess = Start-Process -FilePath $powerShellExe -ArgumentList $processArgs -PassThru -WindowStyle Hidden
        $activeRecord = [ordered]@{ RunId = $runId; Pid = $script:workerProcess.Id; WorkerScript = $workerScript; LaunchNumber = $script:launchCount; StartedAtUtc = [DateTime]::UtcNow.ToString('o') }
        $activeRecord | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $activePath -Encoding UTF8
        Write-Event -Name 'WORKER_STARTED' -Data @{ Pid = $script:workerProcess.Id; LaunchNumber = $script:launchCount; SimulatedCrash = $isCrashAttempt; SimulatedNormalExit = $isNormalExit }

        $observationSeconds = if ($isCrashAttempt -or $isNormalExit) { [Math]::Max($CrashAfterSeconds, $NormalExitAfterSeconds) + 2 } else { $StableObservationSeconds }
        $observationDeadline = [DateTime]::UtcNow.AddSeconds($observationSeconds)
        $workerExited = $false
        $workerExitCode = $null
        $stableWindowElapsed = $false
        $mainExited = $false

        while ([DateTime]::UtcNow -lt $observationDeadline) {
            if (-not (Test-MainAlive)) {
                $mainExited = $true
                break
            }
            $script:workerProcess.Refresh()
            if ($script:workerProcess.HasExited) {
                $workerExited = $true
                $workerExitCode = $script:workerProcess.ExitCode
                break
            }
            Start-Sleep -Milliseconds 200
        }

        if (-not $mainExited -and -not $workerExited -and -not $isCrashAttempt -and -not $isNormalExit -and [DateTime]::UtcNow -ge $observationDeadline) {
            $stableWindowElapsed = $true
        }

        if ($mainExited) {
            $script:result = 'MAIN_PROCESS_EXITED_DURING_WORKER'
            Write-Event -Name 'MAIN_PROCESS_EXITED_DURING_WORKER' -Data @{ Pid = $script:workerProcess.Id }
            break
        }

        if ($stableWindowElapsed) {
            $script:result = 'STABLE_WINDOW_OBSERVED_NOT_HEALTH_PROOF'
            Write-Event -Name 'STABLE_OBSERVATION_WINDOW_ELAPSED' -Data @{ Pid = $script:workerProcess.Id; Seconds = $StableObservationSeconds; Note = 'Process liveness only; no application health, IPC, persistence, or UI behavior was tested.' }
            break
        }

        if ($workerExited -and $workerExitCode -eq 0) {
            $script:result = 'NORMAL_EXIT_NO_RESTART'
            Write-Event -Name 'WORKER_NORMAL_EXIT' -Data @{ LaunchNumber = $script:launchCount; ExitCode = $workerExitCode }
            break
        }

        if ($workerExited) {
            $script:failureCount++
            Write-Event -Name 'WORKER_ABNORMAL_EXIT' -Data @{ LaunchNumber = $script:launchCount; ExitCode = $workerExitCode; FailureCount = $script:failureCount }
        } else {
            $script:failureCount++
            Write-Event -Name 'WORKER_OBSERVATION_TIMEOUT' -Data @{ LaunchNumber = $script:launchCount; FailureCount = $script:failureCount }
        }

        Stop-OwnedWorker

        if ($script:restartCount -ge $MaxRestartAttempts) {
            $script:result = 'DEGRADED_RETRY_BUDGET_EXHAUSTED'
            Write-Event -Name 'DEGRADED' -Data @{ RestartCount = $script:restartCount; MaxRestartAttempts = $MaxRestartAttempts }
            break
        }

        $script:restartCount++
        $delay = Get-BackoffSeconds -RestartNumber $script:restartCount
        Write-Event -Name 'RESTART_BACKOFF_STARTED' -Data @{ RestartNumber = $script:restartCount; DelaySeconds = $delay }
        $backoffDeadline = [DateTime]::UtcNow.AddSeconds($delay)
        while ([DateTime]::UtcNow -lt $backoffDeadline) {
            if (-not (Test-MainAlive)) { break }
            Start-Sleep -Milliseconds 200
        }
        if (-not (Test-MainAlive)) {
            $script:result = 'MAIN_PROCESS_EXITED_DURING_BACKOFF'
            Write-Event -Name 'MAIN_PROCESS_EXITED_DURING_BACKOFF' -Data @{ RestartCount = $script:restartCount }
            break
        }
    }
}
catch {
    $script:result = 'HARNESS_ERROR'
    Write-Event -Name 'HARNESS_ERROR' -Data @{ Message = $_.Exception.Message }
    throw
}
finally {
    Stop-OwnedWorker
    $summary = [ordered]@{
        RunId = $runId
        StartedAtUtc = $startedAt.ToString('o')
        FinishedAtUtc = [DateTime]::UtcNow.ToString('o')
        Result = $script:result
        LaunchCount = $script:launchCount
        RestartCount = $script:restartCount
        FailureCount = $script:failureCount
        MaxRestartAttempts = $MaxRestartAttempts
        InitialBackoffSeconds = $InitialBackoffSeconds
        MaxBackoffSeconds = $MaxBackoffSeconds
        BackoffMultiplier = $BackoffMultiplier
        CrashAttempts = @($CrashAttempts)
        MainProcessLifetimeSeconds = $MainProcessLifetimeSeconds
        EventLog = $eventLog
        HarnessOnly = $true
        Limitations = @('Simulates process lifecycle only.', 'Does not implement Named Pipes, peer authentication, persistence, CardDefinition reconciliation, CardPresentationState, desktop UI, or actual CardHost health checks.', 'Does not validate Keep Cards=ON behavior after Main Process exit.')
    }
    $summary | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $summaryPath -Encoding UTF8
    Write-Host "Result: $script:result"
    Write-Host "Summary: $summaryPath"
    Write-Host "Events:  $eventLog"
}
