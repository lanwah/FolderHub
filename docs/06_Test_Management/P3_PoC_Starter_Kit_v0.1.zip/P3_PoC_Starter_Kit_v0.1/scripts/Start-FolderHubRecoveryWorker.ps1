[CmdletBinding()]
param(
    [int]$Attempt = 1,
    [int]$ExitAfterSeconds = 0,
    [int]$ExitCode = 0
)

$ErrorActionPreference = 'Stop'

if ($ExitAfterSeconds -gt 0) {
    Start-Sleep -Seconds $ExitAfterSeconds
    exit $ExitCode
}

# A stable worker intentionally remains alive until the parent harness stops it.
while ($true) {
    Start-Sleep -Seconds 1
}
