[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$DestinationPath
)

$ErrorActionPreference = 'Stop'
$sourceRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$destination = [System.IO.Path]::GetFullPath($DestinationPath)
if ($destination -eq $sourceRoot) {
    throw 'DestinationPath must not be the source kit directory.'
}
if (Test-Path -LiteralPath $destination) {
    throw "Destination already exists; refusing to overwrite: $destination"
}

New-Item -ItemType Directory -Path $destination -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $sourceRoot 'README.md') -Destination $destination
Copy-Item -LiteralPath (Join-Path $sourceRoot 'scripts') -Destination $destination -Recurse
Copy-Item -LiteralPath (Join-Path $sourceRoot 'docs') -Destination $destination -Recurse
New-Item -ItemType Directory -Path (Join-Path $destination 'artifacts') -Force | Out-Null
Write-Host "PoC kit copied to: $destination"
Write-Host 'No service, scheduled task, registry entry, startup item, or system-wide component was installed.'
